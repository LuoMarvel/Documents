# -*- coding:utf-8 -*-

"""
将K线数据从数据库中取出，然后通过 KlineEvent 事件推送到事件中心。

requirements:
    pip install thenextquant

run:
    python publish_kline.py config.json
"""

import sys

from quant import const
from quant.utils import logger
from quant.utils import tools
from quant.config import config
from quant.quant import quant
from quant.data import KLineData
from quant.event import EventKline
from quant.tasks import SingleTask


class KlinePublish:

    def __init__(self):
        self.platform = config.platform  # 交易平台
        self.symbol = config.symbol  # 交易对
        self.interval = config.interval  # 推送时间间隔(秒)
        self.count = config.count  # 每次推送的条数
        self.start = tools.datetime_str_to_ts(config.start_time, "%Y/%m/%d %H:%M:%S") * 1000
        self.end = tools.datetime_str_to_ts(config.end_time, "%Y/%m/%d %H:%M:%S") * 1000

        self.cur_ts = self.start  # 设置当前查询时间戳为开始时间

        self.db = KLineData(self.platform)

        SingleTask.run(self.do_publish)

    async def do_publish(self, *args, **kwargs):
        start = self.cur_ts
        end = self.cur_ts + 60 * self.count * 1000
        datas = await self.db.get_kline_between_ts(self.symbol, start, end)
        self.cur_ts = end

        for index, d in enumerate(datas):
            EventKline(self.platform, self.symbol, d["o"], d["h"], d["l"], d["c"], None, d["t"], const.MARKET_TYPE_KLINE).publish()
            logger.info("index:", index, "data:", d, caller=self)

        if end > self.end:  # 结束
            logger.info("kline data publish done.", caller=self)
            quant.stop()

        SingleTask.call_later(self.do_publish, self.interval)


if __name__ == "__main__":
    config_file = sys.argv[1]
    quant.initialize(config_file)
    KlinePublish()
    quant.start()
