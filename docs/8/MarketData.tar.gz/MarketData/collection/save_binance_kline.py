# -*- coding:utf-8 -*-

"""
拉取binance的历史数据

requirements:
    pip install python-binance, pymongo

run:
    python save_binance_kline.py
"""

import datetime
import pymongo
from binance.client import Client
from urllib.parse import quote_plus


SYMBOL = "ETH/USDT"
start_ms = 1559318400000  # 开始时间戳
end_ms = 1561910400000  # 截止时间戳


# 创建binance连接
API_KEY = "123456"
API_SECRET = "123456"
binance_client = Client(API_KEY, API_SECRET)

# 创建mongodb连接
c = {
    "host": "127.0.0.1",
    "port": 27017,
    "username": "test",
    "password": "123456"
}
uri = "mongodb://{username}:{password}@{host}:{port}/{dbname}".format(username=quote_plus(c["username"]),
                                                                      password=quote_plus(c["password"]),
                                                                      host=quote_plus(c["host"]),
                                                                      port=c["port"],
                                                                      dbname="admin")
mongo_client = pymongo.MongoClient(uri)
db = mongo_client.get_database("binance")
c_name = "kline_{s}".format(s=SYMBOL).replace("/", "_").lower()
collection = db[c_name]


def get_klines(symbol, start, end):
    datas = []
    klines = binance_client.get_historical_klines(symbol.replace("/", ''), Client.KLINE_INTERVAL_1MINUTE, start, end)
    for item in klines:
        d = {
            "t": item[0],
            "o": item[1],
            "h": item[2],
            "l": item[3],
            "c": item[4]
        }
        datas.append(d)
    return datas


def save_to_db(datas):
    """ 保存到数据库
    """
    if not datas:
        return
    collection.insert_many(datas)


def ts_to_datetime_str(ts):
    """ 将时间戳转换为日期时间格式，年-月-日 时:分:秒
    @param ts 时间戳
    """
    if not ts:
        return "00-00-00 00:00:00"
    dt = datetime.datetime.fromtimestamp(int(ts))
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def main():
    while True:
        global start_ms
        start = start_ms
        end = start_ms + 60 * 60 * 5000  # 计算5个小时后的时间戳
        start_ms = end
        if start_ms > end_ms:
            return

        klines = get_klines(SYMBOL, start, end)
        save_to_db(klines)
        print("length:", len(klines), ", next start:", ts_to_datetime_str(start_ms/1000))


main()
