# -*- coding:utf-8 -*-

"""
订阅 KlineEvent 事件，然后将K线数据保存至数据库。

requirements:
    pip install thenextquant

run:
    python market.py config.json
"""

import sys

from quant import const
from quant.utils import logger
from quant.config import config
from quant.quant import quant
from quant.data import KLineData
from quant.market import Kline, Market


class SaveKline:

    def __init__(self):
        self.platform = config.platform  # 交易平台
        self.symbol = config.symbol  # 交易对

        # 创建db对象
        self.db = KLineData(self.platform)

        # 订阅K线行情事件
        Market(const.MARKET_TYPE_KLINE, self.platform, self.symbol, self.on_event_kline_update)

    async def on_event_kline_update(self, kline: Kline):
        """ K线事件更新回调
        """
        await self.db.create_new_kline(kline)
        logger.info("save new kline:", kline, caller=self)


if __name__ == "__main__":
    config_file = sys.argv[1]
    quant.initialize(config_file)
    SaveKline()
    quant.start()
